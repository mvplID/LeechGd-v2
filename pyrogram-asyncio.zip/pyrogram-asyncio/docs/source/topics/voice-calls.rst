Voice Calls
===========

A working proof-of-concept of Telegram voice calls using Pyrogram can be found here:
https://github.com/bakatrouble/pylibtgvoip. Thanks to `@bakatrouble <https://t.me/bakatrouble>`_.

.. note::

    This page will be updated with more information once voice calls become eventually more usable and more integrated
    in Pyrogram itself.
