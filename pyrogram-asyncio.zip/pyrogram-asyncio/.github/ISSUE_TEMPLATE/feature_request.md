---
name: Feature Request
about: Suggest ideas, new features or enhancements
labels: "enhancement"
---

<!-- WARNING: Ignoring this template could lead to the issue being closed as incomplete -->

## Checklist
- [ ] I believe the idea is awesome and would benefit the library.
- [ ] I have searched in the issue tracker for similar requests, including closed ones.

## Description
A detailed description of the request.